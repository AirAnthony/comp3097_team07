//
//  ViewController.swift
//  GroupProject
//
//  Created by Roman on 2021-03-29.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController, AVPlayerViewControllerDelegate {
    
    var playerController = AVPlayerViewController()
    var playerController2 = AVPlayerViewController()

    
    //variables for budget page
    
    @IBOutlet weak var incomeTotal: UITextField!
    
    @IBOutlet weak var mortgageCost: UITextField!
    
    @IBOutlet weak var insuranceCost: UITextField!
    
    @IBOutlet weak var utilityCost: UITextField!
    
    @IBOutlet weak var phoneCost: UITextField!
    
    @IBOutlet weak var internetCost: UITextField!
    
    @IBOutlet weak var tvCost: UITextField!
    
    @IBOutlet weak var gasCost: UITextField!
    
    @IBOutlet weak var groceriesCost: UITextField!
    
    @IBOutlet weak var entertainmentCost: UITextField!
    
    @IBOutlet weak var childCareCost: UITextField!
    
    @IBOutlet weak var debtCost: UITextField!
    
    @IBOutlet weak var loansCost: UITextField!
    
    @IBOutlet weak var clothesCost: UITextField!
    
    @IBOutlet weak var carCost: UITextField!
    
    @IBOutlet weak var savings: UITextField!
    
    
    @IBOutlet weak var textView: UITextView!
    
    //variables for cooking page
    
    
    @IBOutlet weak var utensilName: UITextField!
    
    @IBOutlet weak var utensilNameTwo: UITextField!
    
    @IBOutlet weak var utensilNameThree: UITextField!
    
    @IBOutlet weak var utensilNameFour: UITextField!
    
    @IBOutlet weak var utensilNameFive: UITextField!
    
    
    @IBOutlet weak var quizPicture: UIImageView!
    
    @IBOutlet weak var quizpictureTwo: UIImageView!
    
    @IBOutlet weak var quizPictureThree: UIImageView!
    
    @IBOutlet weak var quizPictureFour: UIImageView!
    
    @IBOutlet weak var quizPictureFive: UIImageView!
    
   
    
    
    
    var answer: String = "measuring cup, measuring spoons, spatula, roasting pan";
    
    var answerTwo: String = "rolling pin, frying pan, mixing bowl, grater";
    
    var answerThree: String = "meat cleaver, garlic press, colander, mixer"
    
    var answerFour: String = "corkscrew, blender, can opener, potato masher"
    
    var answerFive: String = "ladle, whisk, tongs, strainer"

    @IBAction func btnSubmit(_ sender: Any) {
        if(utensilName.text == answer) {
            quizPicture.image = UIImage(named: "correct")
        }
        else {
            quizPicture.image = UIImage(named: "wrong")
        }
    }
    
    
    @IBAction func btnSubmitTwo(_ sender: Any) {
        if(utensilNameTwo.text == answerTwo) {
            quizpictureTwo.image = UIImage(named: "correct")
        }
        else {
            quizpictureTwo.image = UIImage(named: "wrong")
        }
    }
    
    
    @IBAction func btnSubmitThree(_ sender: Any) {
        if(utensilNameThree.text == answerThree) {
            quizPictureThree.image = UIImage(named: "correct")
        }
        else {
            quizPictureThree.image = UIImage(named: "wrong")
        }
    }
    
    
    
    @IBAction func btnSubmitFour(_ sender: Any) {
        if(utensilNameFour.text == answerFour) {
            quizPictureFour.image = UIImage(named: "correct")
        }
        else {
            quizPictureFour.image = UIImage(named: "wrong")
        }
    }
    
    @IBAction func btnSubmitFive(_ sender: Any) {
        if(utensilNameFive.text == answerFive) {
            quizPictureFive.image = UIImage(named: "correct")
        }
        else {
            quizPictureFive.image = UIImage(named: "wrong")
        }
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func btn_start(_ sender: Any) {
        guard let path = Bundle.main.path(forResource: "intro_video", ofType: "mp4") else {
            debugPrint("intro_video.mp4 not found")
            return
        }
        let player = AVPlayer(url: URL(fileURLWithPath: path))
        let playerController = AVPlayerViewController()
        playerController.player = player
        present(playerController, animated: true) {
            player.play()
        }
    }
    
    
    
    @IBAction func btn_startTwo(_ sender: Any) {
        guard let path = Bundle.main.path(forResource: "breathing_video", ofType: "mp4") else {
            debugPrint("breathing_video.mp4 not found")
            return
        }
        let player = AVPlayer(url: URL(fileURLWithPath: path))
        let playerController = AVPlayerViewController()
        playerController.player = player
        present(playerController, animated: true) {
            player.play()
        }
    }
    
    
    
    @IBAction func enterTapped(_ sender: Any) {
        
        let mortgageOutput = Double(mortgageCost.text!)
        let insuranceOutput = Double(insuranceCost.text!)
        let utilityOuput = Double(utilityCost.text!)
        let phoneOutput = Double(phoneCost.text!)
        let internetOutput = Double(internetCost.text!)
        let tvOutput = Double(tvCost.text!)
        let gasOutput = Double(gasCost.text!)
        let groceryOutput = Double(groceriesCost.text!)
        let entertainmentOutput = Double(entertainmentCost.text!)
        let childCareOutput = Double(childCareCost.text!)
        let debtOutput = Double(debtCost.text!)
        let loansOutput = Double(loansCost.text!)
        let clothesOutput = Double(clothesCost.text!)
        let carOutput = Double(carCost.text!)
        
        let totalOutput = Double(mortgageOutput! + insuranceOutput! + utilityOuput! + phoneOutput! + internetOutput! + tvOutput! + gasOutput! + groceryOutput! + entertainmentOutput! + childCareOutput! + debtOutput! + loansOutput! + clothesOutput! + carOutput!)
        
        let totalOutputString: String = String(totalOutput)
        
        
        textView.text = "Income: \(incomeTotal.text!)\nMortgage: \(mortgageCost.text!)\nInsurance: \(insuranceCost.text!)\nUtility: \(utilityCost.text!)\nPhone: \(phoneCost.text!)\nInternet: \(internetCost.text!)\nT.V: \(tvCost.text!)\nGas: \(gasCost.text!)\nGroceries: \(groceriesCost.text!)\nEntertainment: \(entertainmentCost.text!)\nChild Care: \(childCareCost.text!)\nDebt: \(debtCost.text!)\nLoans: \(loansCost.text!)\nClothes: \(clothesCost.text!)\nCar: \(carCost.text!)\nSavings: \(savings.text!)\nTotal Expenses: \(totalOutputString)"
    }
    

    
 
    

}



extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        
        return true
    }
}
